﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FleetSim.Objects;
using FleetSim.Objects.Class;
using FleetSim.Objects.Interface;

namespace FleetSim.Objects.Interface
{
    // interface for car
    interface Icar
    {
    }
}
