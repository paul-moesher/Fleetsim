﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSim.Objects.Enum
    {
    // enum for car colors
        public enum colors { red =0, white, blue };
    }
